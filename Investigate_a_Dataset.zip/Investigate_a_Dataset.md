# TMDB Movie Analysis


## Table of Contents
<ul>
<li><a href="#intro">Introduction</a></li>
<li><a href="#wrangling">Data Wrangling</a></li>
<li><a href="#eda">Exploratory Data Analysis</a></li>
<li><a href="#conclusions">Conclusions</a></li>
</ul>

<a id='intro'></a>
## Introduction

### Dataset Description 

This dataset is from Kaggle: 5000 Movie Dataset and contains information about 10,000 movies collected from The Movie Database (TMDb), including user ratings and revenue.
The primary goal of this project is to practice pandas, Numpy, and Matplotlib data analysis techniques.


### Questions for Analysis
1) Which genres are most popular from year to year? 
2) How did film budgets change from each decade? 
3) What kinds of properties are associated with movies that have high revenues?

<a id='wrangling'></a>
## Data Wrangling

We will prepare the environment, load and assess dataset.

### General Properties


```python
#import necessary libraries

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
#import and inspect data
df = pd.read_csv('tmdb-movies.csv')
df.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>imdb_id</th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>original_title</th>
      <th>cast</th>
      <th>homepage</th>
      <th>director</th>
      <th>tagline</th>
      <th>...</th>
      <th>overview</th>
      <th>runtime</th>
      <th>genres</th>
      <th>production_companies</th>
      <th>release_date</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>budget_adj</th>
      <th>revenue_adj</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>135397</td>
      <td>tt0369610</td>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Jurassic World</td>
      <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
      <td>http://www.jurassicworld.com/</td>
      <td>Colin Trevorrow</td>
      <td>The park is open.</td>
      <td>...</td>
      <td>Twenty-two years after the events of Jurassic ...</td>
      <td>124</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Universal Studios|Amblin Entertainment|Legenda...</td>
      <td>6/9/15</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>1.379999e+08</td>
      <td>1.392446e+09</td>
    </tr>
    <tr>
      <th>1</th>
      <td>76341</td>
      <td>tt1392190</td>
      <td>28.419936</td>
      <td>150000000</td>
      <td>378436354</td>
      <td>Mad Max: Fury Road</td>
      <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
      <td>http://www.madmaxmovie.com/</td>
      <td>George Miller</td>
      <td>What a Lovely Day.</td>
      <td>...</td>
      <td>An apocalyptic story set in the furthest reach...</td>
      <td>120</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
      <td>5/13/15</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
      <td>1.379999e+08</td>
      <td>3.481613e+08</td>
    </tr>
    <tr>
      <th>2</th>
      <td>262500</td>
      <td>tt2908446</td>
      <td>13.112507</td>
      <td>110000000</td>
      <td>295238201</td>
      <td>Insurgent</td>
      <td>Shailene Woodley|Theo James|Kate Winslet|Ansel...</td>
      <td>http://www.thedivergentseries.movie/#insurgent</td>
      <td>Robert Schwentke</td>
      <td>One Choice Can Destroy You</td>
      <td>...</td>
      <td>Beatrice Prior must confront her inner demons ...</td>
      <td>119</td>
      <td>Adventure|Science Fiction|Thriller</td>
      <td>Summit Entertainment|Mandeville Films|Red Wago...</td>
      <td>3/18/15</td>
      <td>2480</td>
      <td>6.3</td>
      <td>2015</td>
      <td>1.012000e+08</td>
      <td>2.716190e+08</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 21 columns</p>
</div>




```python
#check how many rows and columns
df.shape
```




    (10866, 21)




```python
#Basic information of dataset
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10866 entries, 0 to 10865
    Data columns (total 21 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   id                    10866 non-null  int64  
     1   imdb_id               10856 non-null  object 
     2   popularity            10866 non-null  float64
     3   budget                10866 non-null  int64  
     4   revenue               10866 non-null  int64  
     5   original_title        10866 non-null  object 
     6   cast                  10790 non-null  object 
     7   homepage              2936 non-null   object 
     8   director              10822 non-null  object 
     9   tagline               8042 non-null   object 
     10  keywords              9373 non-null   object 
     11  overview              10862 non-null  object 
     12  runtime               10866 non-null  int64  
     13  genres                10843 non-null  object 
     14  production_companies  9836 non-null   object 
     15  release_date          10866 non-null  object 
     16  vote_count            10866 non-null  int64  
     17  vote_average          10866 non-null  float64
     18  release_year          10866 non-null  int64  
     19  budget_adj            10866 non-null  float64
     20  revenue_adj           10866 non-null  float64
    dtypes: float64(4), int64(6), object(11)
    memory usage: 1.7+ MB



```python
#how many missing values 
df.isnull().sum()
```




    id                         0
    imdb_id                   10
    popularity                 0
    budget                     0
    revenue                    0
    original_title             0
    cast                      76
    homepage                7930
    director                  44
    tagline                 2824
    keywords                1493
    overview                   4
    runtime                    0
    genres                    23
    production_companies    1030
    release_date               0
    vote_count                 0
    vote_average               0
    release_year               0
    budget_adj                 0
    revenue_adj                0
    dtype: int64




```python
#how many duplicated rows
df.duplicated().sum()
```




    1




```python
# checking descriptive statistics
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>runtime</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>budget_adj</th>
      <th>revenue_adj</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>10866.000000</td>
      <td>10866.000000</td>
      <td>1.086600e+04</td>
      <td>1.086600e+04</td>
      <td>10866.000000</td>
      <td>10866.000000</td>
      <td>10866.000000</td>
      <td>10866.000000</td>
      <td>1.086600e+04</td>
      <td>1.086600e+04</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>66064.177434</td>
      <td>0.646441</td>
      <td>1.462570e+07</td>
      <td>3.982332e+07</td>
      <td>102.070863</td>
      <td>217.389748</td>
      <td>5.974922</td>
      <td>2001.322658</td>
      <td>1.755104e+07</td>
      <td>5.136436e+07</td>
    </tr>
    <tr>
      <th>std</th>
      <td>92130.136561</td>
      <td>1.000185</td>
      <td>3.091321e+07</td>
      <td>1.170035e+08</td>
      <td>31.381405</td>
      <td>575.619058</td>
      <td>0.935142</td>
      <td>12.812941</td>
      <td>3.430616e+07</td>
      <td>1.446325e+08</td>
    </tr>
    <tr>
      <th>min</th>
      <td>5.000000</td>
      <td>0.000065</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>10.000000</td>
      <td>1.500000</td>
      <td>1960.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>10596.250000</td>
      <td>0.207583</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>90.000000</td>
      <td>17.000000</td>
      <td>5.400000</td>
      <td>1995.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>20669.000000</td>
      <td>0.383856</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>99.000000</td>
      <td>38.000000</td>
      <td>6.000000</td>
      <td>2006.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>75610.000000</td>
      <td>0.713817</td>
      <td>1.500000e+07</td>
      <td>2.400000e+07</td>
      <td>111.000000</td>
      <td>145.750000</td>
      <td>6.600000</td>
      <td>2011.000000</td>
      <td>2.085325e+07</td>
      <td>3.369710e+07</td>
    </tr>
    <tr>
      <th>max</th>
      <td>417859.000000</td>
      <td>32.985763</td>
      <td>4.250000e+08</td>
      <td>2.781506e+09</td>
      <td>900.000000</td>
      <td>9767.000000</td>
      <td>9.200000</td>
      <td>2015.000000</td>
      <td>4.250000e+08</td>
      <td>2.827124e+09</td>
    </tr>
  </tbody>
</table>
</div>




```python
#lets see different genres and their counts
df['genres'].value_counts()
```




    Comedy                                      712
    Drama                                       712
    Documentary                                 312
    Drama|Romance                               289
    Comedy|Drama                                280
                                               ... 
    Adventure|Animation|Romance                   1
    Family|Animation|Drama                        1
    Action|Adventure|Animation|Comedy|Family      1
    Action|Adventure|Animation|Fantasy            1
    Mystery|Science Fiction|Thriller|Drama        1
    Name: genres, Length: 2039, dtype: int64




### Data Cleaning


```python
#make a copy of the original dataframe
df1=df.copy()
```


```python
#drop duplicated rows
df1.drop_duplicates(inplace=True)
```


```python
#drop unnecessary columns
col = ['id','imdb_id', 'homepage', 'tagline', 'overview','original_title','cast',
       'keywords','overview','production_companies','release_date','budget_adj', 'revenue_adj']
df1.drop(col, axis=1, inplace=True)
```


```python
#confirm that columns are dropped
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>director</th>
      <th>runtime</th>
      <th>genres</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>1</th>
      <td>28.419936</td>
      <td>150000000</td>
      <td>378436354</td>
      <td>George Miller</td>
      <td>120</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>2</th>
      <td>13.112507</td>
      <td>110000000</td>
      <td>295238201</td>
      <td>Robert Schwentke</td>
      <td>119</td>
      <td>Adventure|Science Fiction|Thriller</td>
      <td>2480</td>
      <td>6.3</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.173104</td>
      <td>200000000</td>
      <td>2068178225</td>
      <td>J.J. Abrams</td>
      <td>136</td>
      <td>Action|Adventure|Science Fiction|Fantasy</td>
      <td>5292</td>
      <td>7.5</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9.335014</td>
      <td>190000000</td>
      <td>1506249360</td>
      <td>James Wan</td>
      <td>137</td>
      <td>Action|Crime|Thriller</td>
      <td>2947</td>
      <td>7.3</td>
      <td>2015</td>
    </tr>
  </tbody>
</table>
</div>




```python
#drop null values in genres column
drop = ['genres']
df1.dropna(subset=drop,how='any',inplace=True)
```


```python
#use str.split to split genres
genre_split = df1['genres'].str.split('|').apply(pd.Series,1).stack().reset_index(level=1, drop=True)
```


```python
#name the new column 
genre_split.name = 'genre'
```


```python
#use join to combine columns
df1 = df1.drop(['genres'], axis=1).join(genre_split)
```


```python
#check data to see genres are separated
df1.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>director</th>
      <th>runtime</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Action</td>
    </tr>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Adventure</td>
    </tr>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Science Fiction</td>
    </tr>
  </tbody>
</table>
</div>




```python
#check for genre categories and their total count
df1['genre'].value_counts()
```




    Drama              4760
    Comedy             3793
    Thriller           2907
    Action             2384
    Romance            1712
    Horror             1637
    Adventure          1471
    Crime              1354
    Family             1231
    Science Fiction    1229
    Fantasy             916
    Mystery             810
    Animation           699
    Documentary         520
    Music               408
    History             334
    War                 270
    Foreign             188
    TV Movie            167
    Western             165
    Name: genre, dtype: int64




```python
#above shows that there are 20 genres 
#use unique function to double check 
df1['genre'].unique()
```




    array(['Action', 'Adventure', 'Science Fiction', 'Thriller', 'Fantasy',
           'Crime', 'Western', 'Drama', 'Family', 'Animation', 'Comedy',
           'Mystery', 'Romance', 'War', 'History', 'Music', 'Horror',
           'Documentary', 'TV Movie', 'Foreign'], dtype=object)




```python
#create decade column for the df1 
edges = [1959, 1970, 1980, 1990, 2000, 2010, 2016]

#values that fall within the edges will be placed under these names accordingly 
names = ['1960', '1970', '1980', '1990', '2000', '2010']

#use cut to categorize bin values into discrete intervals 
df1['decade'] = pd.cut(df1['release_year'], edges, labels=names)
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>director</th>
      <th>runtime</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>genre</th>
      <th>decade</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Action</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Adventure</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Science Fiction</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Thriller</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>1</th>
      <td>28.419936</td>
      <td>150000000</td>
      <td>378436354</td>
      <td>George Miller</td>
      <td>120</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
      <td>Action</td>
      <td>2010</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 26955 entries, 0 to 10865
    Data columns (total 10 columns):
     #   Column        Non-Null Count  Dtype   
    ---  ------        --------------  -----   
     0   popularity    26955 non-null  float64 
     1   budget        26955 non-null  int64   
     2   revenue       26955 non-null  int64   
     3   director      26864 non-null  object  
     4   runtime       26955 non-null  int64   
     5   vote_count    26955 non-null  int64   
     6   vote_average  26955 non-null  float64 
     7   release_year  26955 non-null  int64   
     8   genre         26955 non-null  object  
     9   decade        26955 non-null  category
    dtypes: category(1), float64(2), int64(5), object(2)
    memory usage: 2.1+ MB


<a id='eda'></a>
## Exploratory Data Analysis


### Question 1: Which genres are most popular from year to year?


```python
#make a copy of the df1/cleaned data frame
genre=df1.copy()
```


```python
#use groupby where first grouping is based on 'release year' and within each release year, group based on 'genre'

genre=genre.groupby(['release_year', 'genre']).size().reset_index(name='count')
genre.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>release_year</th>
      <th>genre</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1960</td>
      <td>Action</td>
      <td>8</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1960</td>
      <td>Adventure</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1960</td>
      <td>Comedy</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1960</td>
      <td>Crime</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1960</td>
      <td>Drama</td>
      <td>13</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1960</td>
      <td>Family</td>
      <td>3</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1960</td>
      <td>Fantasy</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1960</td>
      <td>Foreign</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1960</td>
      <td>History</td>
      <td>5</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1960</td>
      <td>Horror</td>
      <td>7</td>
    </tr>
  </tbody>
</table>
</div>




```python
genre.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1049 entries, 0 to 1048
    Data columns (total 3 columns):
     #   Column        Non-Null Count  Dtype 
    ---  ------        --------------  ----- 
     0   release_year  1049 non-null   int64 
     1   genre         1049 non-null   object
     2   count         1049 non-null   int64 
    dtypes: int64(2), object(1)
    memory usage: 24.7+ KB



```python
#group based on 'release year' but not as new index   
#use apply to accompany the following function; lambda 
#lambda function sorts data frame from the column 'count', minimum being 1 count
#reset_index(drop=True) is used to drop the current index of the df and replace it with index of increaseing integer
popular=genre.groupby(by='release_year', as_index=False).apply(lambda x: x.sort_values('count').tail(1)).reset_index(drop=True)
popular
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>release_year</th>
      <th>genre</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1960</td>
      <td>Drama</td>
      <td>13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1961</td>
      <td>Drama</td>
      <td>16</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1962</td>
      <td>Drama</td>
      <td>21</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1963</td>
      <td>Drama</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1964</td>
      <td>Drama</td>
      <td>20</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1965</td>
      <td>Drama</td>
      <td>20</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1966</td>
      <td>Comedy</td>
      <td>16</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1967</td>
      <td>Comedy</td>
      <td>17</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1968</td>
      <td>Drama</td>
      <td>20</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1969</td>
      <td>Drama</td>
      <td>13</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1970</td>
      <td>Drama</td>
      <td>19</td>
    </tr>
    <tr>
      <th>11</th>
      <td>1971</td>
      <td>Drama</td>
      <td>30</td>
    </tr>
    <tr>
      <th>12</th>
      <td>1972</td>
      <td>Drama</td>
      <td>16</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1973</td>
      <td>Drama</td>
      <td>31</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1974</td>
      <td>Drama</td>
      <td>21</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1975</td>
      <td>Drama</td>
      <td>17</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1976</td>
      <td>Drama</td>
      <td>22</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1977</td>
      <td>Drama</td>
      <td>24</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1978</td>
      <td>Drama</td>
      <td>29</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1979</td>
      <td>Drama</td>
      <td>30</td>
    </tr>
    <tr>
      <th>20</th>
      <td>1980</td>
      <td>Drama</td>
      <td>32</td>
    </tr>
    <tr>
      <th>21</th>
      <td>1981</td>
      <td>Drama</td>
      <td>32</td>
    </tr>
    <tr>
      <th>22</th>
      <td>1982</td>
      <td>Drama</td>
      <td>33</td>
    </tr>
    <tr>
      <th>23</th>
      <td>1983</td>
      <td>Drama</td>
      <td>35</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1984</td>
      <td>Drama</td>
      <td>40</td>
    </tr>
    <tr>
      <th>25</th>
      <td>1985</td>
      <td>Comedy</td>
      <td>51</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1986</td>
      <td>Drama</td>
      <td>51</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1987</td>
      <td>Comedy</td>
      <td>57</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1988</td>
      <td>Comedy</td>
      <td>69</td>
    </tr>
    <tr>
      <th>29</th>
      <td>1989</td>
      <td>Comedy</td>
      <td>63</td>
    </tr>
    <tr>
      <th>30</th>
      <td>1990</td>
      <td>Drama</td>
      <td>60</td>
    </tr>
    <tr>
      <th>31</th>
      <td>1991</td>
      <td>Drama</td>
      <td>63</td>
    </tr>
    <tr>
      <th>32</th>
      <td>1992</td>
      <td>Drama</td>
      <td>65</td>
    </tr>
    <tr>
      <th>33</th>
      <td>1993</td>
      <td>Drama</td>
      <td>90</td>
    </tr>
    <tr>
      <th>34</th>
      <td>1994</td>
      <td>Comedy</td>
      <td>88</td>
    </tr>
    <tr>
      <th>35</th>
      <td>1995</td>
      <td>Drama</td>
      <td>93</td>
    </tr>
    <tr>
      <th>36</th>
      <td>1996</td>
      <td>Drama</td>
      <td>104</td>
    </tr>
    <tr>
      <th>37</th>
      <td>1997</td>
      <td>Drama</td>
      <td>83</td>
    </tr>
    <tr>
      <th>38</th>
      <td>1998</td>
      <td>Drama</td>
      <td>108</td>
    </tr>
    <tr>
      <th>39</th>
      <td>1999</td>
      <td>Drama</td>
      <td>113</td>
    </tr>
    <tr>
      <th>40</th>
      <td>2000</td>
      <td>Drama</td>
      <td>101</td>
    </tr>
    <tr>
      <th>41</th>
      <td>2001</td>
      <td>Comedy</td>
      <td>101</td>
    </tr>
    <tr>
      <th>42</th>
      <td>2002</td>
      <td>Drama</td>
      <td>130</td>
    </tr>
    <tr>
      <th>43</th>
      <td>2003</td>
      <td>Comedy</td>
      <td>111</td>
    </tr>
    <tr>
      <th>44</th>
      <td>2004</td>
      <td>Drama</td>
      <td>141</td>
    </tr>
    <tr>
      <th>45</th>
      <td>2005</td>
      <td>Drama</td>
      <td>182</td>
    </tr>
    <tr>
      <th>46</th>
      <td>2006</td>
      <td>Drama</td>
      <td>197</td>
    </tr>
    <tr>
      <th>47</th>
      <td>2007</td>
      <td>Drama</td>
      <td>197</td>
    </tr>
    <tr>
      <th>48</th>
      <td>2008</td>
      <td>Drama</td>
      <td>233</td>
    </tr>
    <tr>
      <th>49</th>
      <td>2009</td>
      <td>Drama</td>
      <td>224</td>
    </tr>
    <tr>
      <th>50</th>
      <td>2010</td>
      <td>Drama</td>
      <td>210</td>
    </tr>
    <tr>
      <th>51</th>
      <td>2011</td>
      <td>Drama</td>
      <td>214</td>
    </tr>
    <tr>
      <th>52</th>
      <td>2012</td>
      <td>Drama</td>
      <td>232</td>
    </tr>
    <tr>
      <th>53</th>
      <td>2013</td>
      <td>Drama</td>
      <td>253</td>
    </tr>
    <tr>
      <th>54</th>
      <td>2014</td>
      <td>Drama</td>
      <td>284</td>
    </tr>
    <tr>
      <th>55</th>
      <td>2015</td>
      <td>Drama</td>
      <td>260</td>
    </tr>
  </tbody>
</table>
</div>




```python
#check for most popular genres
popular['genre'].unique()
```




    array(['Drama', 'Comedy'], dtype=object)




```python
#check how many Drama and Comedy bars to expect on graph
popular['genre'].value_counts()
```




    Drama     47
    Comedy     9
    Name: genre, dtype: int64




```python
#set figure size
plt.figure(figsize = (30,10))

#use seaborn to barplot with bar color respective to popular genre 
sns.barplot(x = 'release_year', y = 'count', data = popular, hue='genre',dodge=False)

plt.title("Which genres are most popular from year to year?", fontsize = 20)
plt.xlabel("Year", fontsize = 20)
plt.ylabel("Movie Production Count", fontsize = 20)
plt.legend(prop={"size":20})

plt.show()
```


    
![png](output_32_0.png)
    


### Answers

1) Top two most popular genres are Drama and Comedy
2) Drama has been most popular generally from year to year





### Question 2 : How did film budgets change from each decade?



```python
#make a copy of the df1/cleaned df
budget = df1.copy()
```


```python
budget=budget.groupby('decade')['budget'].mean().reset_index(name='budget')
budget
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>decade</th>
      <th>budget</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1960</td>
      <td>2.202421e+06</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1970</td>
      <td>2.975516e+06</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1980</td>
      <td>7.598380e+06</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1990</td>
      <td>2.039298e+07</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2000</td>
      <td>2.222758e+07</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2010</td>
      <td>1.815299e+07</td>
    </tr>
  </tbody>
</table>
</div>




```python
#set figure size 
plt.figure(figsize = (15,5))

#use seaborn to lineplot average film budget per decade 
sns.barplot(x = 'decade', y = 'budget', data = budget)

plt.title("Average Film Budget", fontsize = 30)
plt.xlabel("Decade", fontsize = 20)
plt.ylabel("$ millions", fontsize = 20)


plt.show()
```


    
![png](output_37_0.png)
    


### Answers

1) 1990s has the highest film budget on average while 1970s has the lowest
2) There is an increase in film production budget from 1970s to 1990s
3) There is a decrease in film production budget from 1990s to 2010s

### Question 3: What kinds of properties are associated with movies that have high revenues?


```python
#make a copy of the df1/cleaned df
revenue = df1.copy()
revenue.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>director</th>
      <th>runtime</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>genre</th>
      <th>decade</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Action</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Adventure</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Science Fiction</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>Thriller</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>1</th>
      <td>28.419936</td>
      <td>150000000</td>
      <td>378436354</td>
      <td>George Miller</td>
      <td>120</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
      <td>Action</td>
      <td>2010</td>
    </tr>
  </tbody>
</table>
</div>




```python
#makeing new df where it's sorted by decreasing revenue
high_revenue = revenue.sort_values(by = ['revenue'], ascending = [False])
high_revenue.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>director</th>
      <th>runtime</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>genre</th>
      <th>decade</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1386</th>
      <td>9.432768</td>
      <td>237000000</td>
      <td>2781505847</td>
      <td>James Cameron</td>
      <td>162</td>
      <td>8458</td>
      <td>7.1</td>
      <td>2009</td>
      <td>Action</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>1386</th>
      <td>9.432768</td>
      <td>237000000</td>
      <td>2781505847</td>
      <td>James Cameron</td>
      <td>162</td>
      <td>8458</td>
      <td>7.1</td>
      <td>2009</td>
      <td>Adventure</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>1386</th>
      <td>9.432768</td>
      <td>237000000</td>
      <td>2781505847</td>
      <td>James Cameron</td>
      <td>162</td>
      <td>8458</td>
      <td>7.1</td>
      <td>2009</td>
      <td>Fantasy</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>1386</th>
      <td>9.432768</td>
      <td>237000000</td>
      <td>2781505847</td>
      <td>James Cameron</td>
      <td>162</td>
      <td>8458</td>
      <td>7.1</td>
      <td>2009</td>
      <td>Science Fiction</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.173104</td>
      <td>200000000</td>
      <td>2068178225</td>
      <td>J.J. Abrams</td>
      <td>136</td>
      <td>5292</td>
      <td>7.5</td>
      <td>2015</td>
      <td>Action</td>
      <td>2010</td>
    </tr>
  </tbody>
</table>
</div>




```python
#use panda corr function to see correlation of the high_revenue df 
high_rev_corr=high_revenue.corr(numeric_only=True)
high_rev_corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>runtime</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>popularity</th>
      <td>1.000000</td>
      <td>0.541758</td>
      <td>0.665801</td>
      <td>0.142398</td>
      <td>0.794882</td>
      <td>0.233379</td>
      <td>0.110153</td>
    </tr>
    <tr>
      <th>budget</th>
      <td>0.541758</td>
      <td>1.000000</td>
      <td>0.729429</td>
      <td>0.201128</td>
      <td>0.641743</td>
      <td>0.101052</td>
      <td>0.147880</td>
    </tr>
    <tr>
      <th>revenue</th>
      <td>0.665801</td>
      <td>0.729429</td>
      <td>1.000000</td>
      <td>0.171686</td>
      <td>0.798649</td>
      <td>0.195299</td>
      <td>0.081189</td>
    </tr>
    <tr>
      <th>runtime</th>
      <td>0.142398</td>
      <td>0.201128</td>
      <td>0.171686</td>
      <td>1.000000</td>
      <td>0.174363</td>
      <td>0.158572</td>
      <td>-0.135148</td>
    </tr>
    <tr>
      <th>vote_count</th>
      <td>0.794882</td>
      <td>0.641743</td>
      <td>0.798649</td>
      <td>0.174363</td>
      <td>1.000000</td>
      <td>0.279316</td>
      <td>0.131383</td>
    </tr>
    <tr>
      <th>vote_average</th>
      <td>0.233379</td>
      <td>0.101052</td>
      <td>0.195299</td>
      <td>0.158572</td>
      <td>0.279316</td>
      <td>1.000000</td>
      <td>-0.125364</td>
    </tr>
    <tr>
      <th>release_year</th>
      <td>0.110153</td>
      <td>0.147880</td>
      <td>0.081189</td>
      <td>-0.135148</td>
      <td>0.131383</td>
      <td>-0.125364</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#use seaborn to visualize the correlation above 
sns.heatmap(high_rev_corr, xticklabels=True, annot=True, cmap='Greens')
plt.title('Correlation Heatmap')
plt.show()
```


    
![png](output_43_0.png)
    



```python
#vote count has highest correlation of 0.8
sns.relplot(x='vote_count', y='revenue', data=high_rev_corr, kind="scatter")
plt.show()
```


    
![png](output_44_0.png)
    



```python
#budget has second highest correlation of 0.73
sns.relplot(x='budget', y='revenue', data=high_rev_corr, kind="scatter")
plt.show()
```


    
![png](output_45_0.png)
    



```python
#popularity has the 3rd highest correlation of 0.67
sns.relplot(x='popularity', y='revenue', data=high_rev_corr, kind="scatter")
plt.show()
```


    
![png](output_46_0.png)
    


### Answer

Vote Count, Budget, and Popularity Points show highest association with movies that have high revenues

<a id='conclusions'></a>
## Conclusions

### Summary

1) The top two most popular genres are Drama and Comedy.
2) Drama has been most popular generally from 1960 to 2015.
3) 1990s has the highest film budget on average while 1970s has the lowest.
4) There is an increase in budget from 1970s to 1990s.
5) There is a decrease in budget from 1990s to 2010s.
6) Vote Count, Budget, and Popularity has highest association with the movies that have high revenues.


### Limitations:
1) The dataset contains null and zero values in some features. These zero and null values hinders the analysis and have to be removed. so data cleaning is a necessary part before moving on to the dataset's investigation.
2) There were multiple genres in each movie, I split the genress so each genre is allocated to 1 row.
3) The revenue and budget were not denominated in currency, so it’s unsure whether they are in USD, or another currency.


```python
# Running this cell will execute a bash command to convert this notebook to an .html file
!python -m nbconvert --to html Investigate_a_Dataset.ipynb
```

    [NbConvertApp] Converting notebook Investigate_a_Dataset.ipynb to html
    [NbConvertApp] WARNING | Alternative text is missing on 6 image(s).
    [NbConvertApp] Writing 578372 bytes to Investigate_a_Dataset.html

